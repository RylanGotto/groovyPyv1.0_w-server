"""
This module purely to prevent circular reference within package problems.
"""

class MP3DetailsException(Exception):
    """IDV3 lookup exception"""
    pass
