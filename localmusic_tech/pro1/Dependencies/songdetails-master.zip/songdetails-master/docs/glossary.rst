.. _glossary:

Glossary
========

.. glossary::

   	free bitrate
   		MPEG (:term:`CBR`) where frame bitrate is ``0`` and requires *second* 
   		frame to calculate the actual bitrate of MPEG.
   		
   	CBR
   		Constant Bitrate MPEG.
   		
   	VBR
   		Variable Bitrate MPEG.