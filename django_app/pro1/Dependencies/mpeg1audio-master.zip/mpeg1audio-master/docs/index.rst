.. MPEG-1 Audio Python package documentation master file, created by
   sphinx-quickstart on Sat Jan 09 17:38:04 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
    
MPEG-1 Audio Python package's documentation.
=======================================================

.. note::

	This does not provide any kind of updating or playing the mpeg audio files, 
	only *reading out meta data*.

 
.. autosummary::
    :toctree: api
    
    mpeg1audio
    
.. toctree::
    :maxdepth: 2

    glossary
    laziness
	
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
